# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: admin-generated.spec.ts >> generated host admin shell renders on desktop and mobile
- Location: tests/admin-generated.spec.ts:247:5

# Error details

```
TimeoutError: page.waitForSelector: Timeout 15000ms exceeded.
Call log:
  - waiting for locator('[data-phx-session].phx-connected')

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e5]:
    - generic [ref=e6]:
      - link "Sigra admin overview" [ref=e7] [cursor=pointer]:
        - /url: /admin
        - text: Admin
      - generic [ref=e9]: Global
    - generic [ref=e10]:
      - radiogroup "Theme" [ref=e11]:
        - radio "Light" [ref=e12]
        - radio "Dark" [ref=e13]
        - radio "System" [checked] [ref=e14]
      - button "Open command palette" [ref=e15]: Jump to… ⌘K
  - generic [ref=e16]:
    - navigation "Breadcrumb" [ref=e17]:
      - list [ref=e18]:
        - listitem [ref=e19]:
          - generic [ref=e20]:
            - link "Overview" [ref=e21] [cursor=pointer]:
              - /url: /admin
            - text: /
        - listitem [ref=e22]:
          - generic [ref=e23]: Auth branding
    - generic [ref=e24]:
      - complementary [ref=e25]:
        - navigation "Admin navigation" [ref=e26]:
          - generic [ref=e27]:
            - paragraph [ref=e28]: Overviews
            - list [ref=e29]:
              - listitem [ref=e30]:
                - link "Global overview" [ref=e31] [cursor=pointer]:
                  - /url: /admin
          - generic [ref=e32]:
            - paragraph [ref=e33]: Workspace
            - list [ref=e34]:
              - listitem [ref=e35]:
                - link "Users" [ref=e36] [cursor=pointer]:
                  - /url: /admin/users
              - listitem [ref=e37]:
                - link "Audit" [ref=e38] [cursor=pointer]:
                  - /url: /admin/audit
              - listitem [ref=e39]:
                - link "Branding" [ref=e40] [cursor=pointer]:
                  - /url: /admin/auth-branding
      - main [ref=e41]:
        - generic [ref=e42]:
          - generic [ref=e43]:
            - paragraph [ref=e44]: Branding
            - heading "Auth forms and emails" [level=1] [ref=e45]
            - paragraph [ref=e46]: Tune the generated sign-in, account, invitation, and transactional email defaults without replacing the host-owned templates.
          - generic [ref=e47]: Global auth/email profile
          - generic [ref=e48]:
            - generic [ref=e51]:
              - heading "Brand tokens" [level=2] [ref=e52]
              - paragraph [ref=e53]: "Source: Config defaults"
            - navigation "Branding sections" [ref=e54]:
              - link "Light" [ref=e55] [cursor=pointer]:
                - /url: /admin/auth-branding?panel=light
              - link "Dark" [ref=e56] [cursor=pointer]:
                - /url: /admin/auth-branding?panel=dark
              - link "Details" [ref=e57] [cursor=pointer]:
                - /url: /admin/auth-branding?panel=details
            - generic [ref=e59]:
              - region "Light" [ref=e60]:
                - generic [ref=e61]:
                  - group "Light palette" [ref=e63]:
                    - generic [ref=e64]: Light palette
                    - paragraph [ref=e65]: Shown on generated auth screens when Light is selected.
                    - generic [ref=e66]:
                      - generic [ref=e67]:
                        - text: Accent
                        - generic [ref=e68]:
                          - textbox "Accent" [ref=e69]: "#c2410c"
                          - text: "#c2410c"
                      - generic [ref=e70]:
                        - text: On accent
                        - generic [ref=e71]:
                          - textbox "On accent" [ref=e72]: "#ffffff"
                          - text: "#ffffff"
                      - generic [ref=e73]:
                        - text: Background
                        - generic [ref=e74]:
                          - textbox "Background" [ref=e75]: "#f7f4ee"
                          - text: "#f7f4ee"
                      - generic [ref=e76]:
                        - text: Surface
                        - generic [ref=e77]:
                          - textbox "Surface" [ref=e78]: "#ffffff"
                          - text: "#ffffff"
                      - generic [ref=e79]:
                        - text: Text
                        - generic [ref=e80]:
                          - textbox "Text" [ref=e81]: "#171717"
                          - text: "#171717"
                      - generic [ref=e82]:
                        - text: Muted
                        - generic [ref=e83]:
                          - textbox "Muted" [ref=e84]: "#6b6258"
                          - text: "#6b6258"
                      - generic [ref=e85]:
                        - text: Border
                        - generic [ref=e86]:
                          - textbox "Border" [ref=e87]: "#ded8cf"
                          - text: "#ded8cf"
                  - generic [ref=e88]:
                    - generic [ref=e89]:
                      - heading "Sign-in preview" [level=2] [ref=e90]
                      - generic [ref=e93]:
                        - paragraph [ref=e99]: SigraAdminSmoke
                        - generic [ref=e100]:
                          - heading "Log in" [level=1] [ref=e101]
                          - paragraph [ref=e102]: Use a magic link, passkey, password, or enterprise SSO.
                          - generic [ref=e103]:
                            - generic [ref=e104]:
                              - text: Email
                              - textbox "Email" [ref=e105]: alex@example.com
                            - button "Send magic link" [ref=e106] [cursor=pointer]
                    - generic [ref=e107]:
                      - heading "Email preview" [level=2] [ref=e108]
                      - generic [ref=e110]:
                        - strong [ref=e111]: SigraAdminSmoke
                        - paragraph [ref=e112]: Confirm your email address by clicking the button below.
                        - generic [ref=e113]: Confirm email
              - button "Save profile" [ref=e115] [cursor=pointer]
```

# Test source

```ts
  1   | import { test, expect, type Page } from "@playwright/test";
  2   | import AxeBuilder from "@axe-core/playwright";
  3   | import { captureAdminCheckpoint } from "../helpers/adminArtifacts";
  4   | import { adminUsersEmailLocator } from "../helpers/adminUsersIndex";
  5   | import { TEST_PASSWORD } from "../helpers/fixtures";
  6   | 
  7   | // Generated-host admin and adopter-experience parity smoke.
  8   | //
  9   | // Per D-03, D-05, D-17, D-20, D-21, D-24, and D-25 this spec stays narrow and
  10  | // deterministic. It proves installer/template/runtime parity for the shipped
  11  | // admin seams ONLY:
  12  | //
  13  | //   * shell render on desktop and mobile,
  14  | //   * visible scope labels (Global + organization name),
  15  | //   * admin navigation presence (desktop sidebar + mobile bottom nav),
  16  | //   * allowed organization access (200 + scope label + org-scoped admin content),
  17  | //   * denied global admin access (403 + explicit copy),
  18  | //   * not-found out-of-scope organization access (404 + explicit copy).
  19  | //
  20  | // Broader negative-case matrices, sensitive-mutation guards, filter
  21  | // permutations, and example-app workflow depth stay outside this spec — they
  22  | // are owned by `test/sigra/**`, `test/example/test/**`, and the example-app
  23  | // Playwright behavior suite (D-06, D-07, D-15, D-18).
  24  | 
  25  | const platformAdminEmail =
  26  |   process.env.SIGRA_PLATFORM_ADMIN_EMAIL ?? "platform-admin@example.test";
  27  | const orgAdminEmail =
  28  |   process.env.SIGRA_ORG_ADMIN_EMAIL ?? "org-admin@example.test";
  29  | const adminPassword = process.env.SIGRA_ADMIN_PASSWORD ?? TEST_PASSWORD;
  30  | const allowedOrgSlug = process.env.SIGRA_ALLOWED_ORG_SLUG ?? "allowed-org";
  31  | const allowedOrgName = process.env.SIGRA_ALLOWED_ORG_NAME ?? "Allowed Org";
  32  | const otherOrgSlug = process.env.SIGRA_OTHER_ORG_SLUG ?? "other-scope";
  33  | const impersonationTargetEmail =
  34  |   process.env.SIGRA_IMPERSONATION_TARGET_EMAIL ??
  35  |   "impersonation-target@example.test";
  36  | 
  37  | const DESKTOP_VIEWPORT = { width: 1280, height: 900 };
  38  | const MOBILE_VIEWPORT = { width: 390, height: 844 };
  39  | 
  40  | async function waitForLiveViewReady(page: Page) {
> 41  |   await page.waitForSelector("[data-phx-session].phx-connected", {
      |              ^ TimeoutError: page.waitForSelector: Timeout 15000ms exceeded.
  42  |     state: "attached",
  43  |   });
  44  | }
  45  | 
  46  | async function confirmSudo(page: Page, password: string) {
  47  |   await expect(page).toHaveURL(/\/users\/sudo\?/);
  48  |   // Ratified copy per installer template sudo_html.ex and example sudo_html.ex.
  49  |   // The old heading was stale; reconciled to "Re-enter your password" (Phase 208.1-02).
  50  |   await expect(
  51  |     page.getByRole("heading", { name: "Re-enter your password" }),
  52  |   ).toBeVisible();
  53  |   await page.fill('input[name="sudo[password]"]', password);
  54  |   await page.getByRole("button", { name: "Confirm password" }).click();
  55  | }
  56  | 
  57  | /** Admin shell chrome (avoids inner LiveView `<header>` on nested admin pages). */
  58  | function adminShellHeader(page: Page) {
  59  |   return page.locator("header").filter({ hasText: "Admin" }).first();
  60  | }
  61  | 
  62  | async function logIn(
  63  |   page: Parameters<typeof test>[0]["page"],
  64  |   email: string,
  65  |   password: string,
  66  | ) {
  67  |   await page.goto("/users/log_in");
  68  |   await expect(page.getByRole("heading", { name: "Sign in" })).toBeVisible();
  69  |   await page.locator("details.sigra-auth-disclosure > summary").click();
  70  |   const passwordForm = page.locator("#login_form");
  71  |   await passwordForm.getByLabel("Email", { exact: true }).fill(email);
  72  |   await passwordForm.getByLabel("Password", { exact: true }).fill(password);
  73  |   await passwordForm
  74  |     .getByRole("button", { name: "Sign in with password" })
  75  |     .click();
  76  |   await expect(page).not.toHaveURL(/\/users\/log_in(\?|$)/);
  77  | }
  78  | 
  79  | test("generated auth shell communicates hierarchy and survives theme and reflow states", async ({
  80  |   page,
  81  | }, testInfo) => {
  82  |   await page.setViewportSize(DESKTOP_VIEWPORT);
  83  |   await page.goto("/users/log_in");
  84  | 
  85  |   await expect(page.getByRole("heading", { name: "Sign in" })).toBeVisible();
  86  |   await expect(
  87  |     page.getByRole("button", { name: "Email me a sign-in link" }),
  88  |   ).toBeVisible();
  89  | 
  90  |   const alternatives = page.locator("details.sigra-auth-disclosure");
  91  |   await expect(alternatives).not.toHaveAttribute("open", "");
  92  |   const alternativesSummary = alternatives.locator("summary");
  93  |   for (let index = 0; index < 4; index += 1) {
  94  |     await page.keyboard.press("Tab");
  95  |   }
  96  |   await expect(alternativesSummary).toBeFocused();
  97  |   await expect(alternativesSummary).not.toHaveCSS("box-shadow", "none");
  98  |   await page.keyboard.press("Enter");
  99  |   await expect(alternatives).toHaveAttribute("open", "");
  100 |   await expect(
  101 |     page.getByRole("button", { name: "Sign in with password" }),
  102 |   ).toBeVisible();
  103 |   await expect(
  104 |     page.getByRole("heading", { name: "Work sign-in" }),
  105 |   ).toBeVisible();
  106 | 
  107 |   const authAssetBudget = await page.evaluate(() => {
  108 |     const entries = performance
  109 |       .getEntriesByType("resource")
  110 |       .filter((entry) => new URL(entry.name).pathname.endsWith("/sigra_auth.css")) as PerformanceResourceTiming[];
  111 | 
  112 |     return {
  113 |       count: entries.length,
  114 |       decodedBytes: entries.reduce((sum, entry) => sum + entry.decodedBodySize, 0),
  115 |     };
  116 |   });
  117 |   expect(authAssetBudget.count).toBe(1);
  118 |   expect(authAssetBudget.decodedBytes).toBeLessThanOrEqual(35_000);
  119 | 
  120 |   const authRoot = page.locator("main.sigra-auth");
  121 |   await expect(authRoot).toHaveAttribute("data-theme", "system");
  122 |   await page.emulateMedia({ reducedMotion: "reduce" });
  123 | 
  124 |   const themeSnapshot = async (theme: "light" | "dark" | "system") => {
  125 |     await authRoot.evaluate((element, value) => {
  126 |       element.setAttribute("data-theme", value);
  127 |     }, theme);
  128 | 
  129 |     return authRoot.evaluate((element) => {
  130 |       const style = getComputedStyle(element);
  131 |       return {
  132 |         background: style.getPropertyValue("--sigra-auth-bg").trim(),
  133 |         colorScheme: style.colorScheme,
  134 |       };
  135 |     });
  136 |   };
  137 | 
  138 |   const light = await themeSnapshot("light");
  139 |   await captureAdminCheckpoint(page, testInfo, {
  140 |     name: "auth-login-light-desktop",
  141 |     prefix: "auth",
```