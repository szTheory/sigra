# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: admin-generated.spec.ts >> VFY-01 generated host global users index >> lists users for platform admin
- Location: tests/admin-generated.spec.ts:380:7

# Error details

```
TimeoutError: page.waitForSelector: Timeout 15000ms exceeded.
Call log:
  - waiting for locator('[data-phx-session].phx-connected')

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e5]:
    - generic [ref=e6]:
      - link "Sigra admin overview" [ref=e7] [cursor=pointer]:
        - /url: /admin
        - text: Admin
      - generic [ref=e9]: Global
    - generic [ref=e10]:
      - radiogroup "Theme" [ref=e11]:
        - radio "Light" [ref=e12]
        - radio "Dark" [ref=e13]
        - radio "System" [checked] [ref=e14]
      - button "Open command palette" [ref=e15]: Jump to… ⌘K
  - generic [ref=e16]:
    - navigation "Breadcrumb" [ref=e17]:
      - list [ref=e18]:
        - listitem [ref=e19]:
          - generic [ref=e20]:
            - link "Overview" [ref=e21] [cursor=pointer]:
              - /url: /admin
            - text: /
        - listitem [ref=e22]:
          - generic [ref=e23]: Users
    - generic [ref=e24]:
      - complementary [ref=e25]:
        - navigation "Admin navigation" [ref=e26]:
          - generic [ref=e27]:
            - paragraph [ref=e28]: Overviews
            - list [ref=e29]:
              - listitem [ref=e30]:
                - link "Global overview" [ref=e31] [cursor=pointer]:
                  - /url: /admin
          - generic [ref=e32]:
            - paragraph [ref=e33]: Workspace
            - list [ref=e34]:
              - listitem [ref=e35]:
                - link "Users" [ref=e36] [cursor=pointer]:
                  - /url: /admin/users
              - listitem [ref=e37]:
                - link "Audit" [ref=e38] [cursor=pointer]:
                  - /url: /admin/audit
              - listitem [ref=e39]:
                - link "Branding" [ref=e40] [cursor=pointer]:
                  - /url: /admin/auth-branding
      - main [ref=e41]:
        - generic [ref=e42]:
          - generic [ref=e43]:
            - paragraph [ref=e44]: User operations
            - heading "Users" [level=1] [ref=e45]
          - generic [ref=e46]: Global user operations
          - region "User health" [ref=e47]:
            - heading "User health" [level=2] [ref=e48]
            - generic "User health summary" [ref=e49]:
              - generic [ref=e50]:
                - term [ref=e51]:
                  - img [ref=e53]
                  - generic [ref=e58]: Total users
                - definition [ref=e59]:
                  - generic [ref=e60]: "3"
                - definition [ref=e61]: total users
              - generic [ref=e62]:
                - term [ref=e63]:
                  - img [ref=e65]
                  - generic [ref=e68]: Locked users
                - definition [ref=e69]:
                  - generic [ref=e70]: "0"
                - definition [ref=e71]: locked out
                - definition [ref=e72]: 0% of total users
              - generic [ref=e73]:
                - term [ref=e74]:
                  - img [ref=e76]
                  - generic [ref=e79]: Deletion scheduled
                - definition [ref=e80]:
                  - generic [ref=e81]: "0"
                - definition [ref=e82]: pending deletion
                - definition [ref=e83]: 0% of total users
          - region "Find users" [ref=e84]:
            - heading "Find users" [level=2] [ref=e86]
            - generic [ref=e87]:
              - generic [ref=e88]:
                - generic [ref=e89]:
                  - text: Search
                  - textbox "Search" [ref=e90]:
                    - /placeholder: Email, user id, or name
                - button "Search" [ref=e91] [cursor=pointer]
                - link "Clear" [ref=e92] [cursor=pointer]:
                  - /url: /admin/users
              - generic [ref=e93]:
                - generic [ref=e94] [cursor=pointer]:
                  - checkbox "confirmed" [ref=e95]
                  - generic [ref=e96]: confirmed
                - generic [ref=e97] [cursor=pointer]:
                  - checkbox "mfa" [ref=e98]
                  - generic [ref=e99]: mfa
                - generic [ref=e100] [cursor=pointer]:
                  - checkbox "passkeys" [ref=e101]
                  - generic [ref=e102]: passkeys
                - generic [ref=e103] [cursor=pointer]:
                  - checkbox "locked" [ref=e104]
                  - generic [ref=e105]: locked
                - generic [ref=e106] [cursor=pointer]:
                  - checkbox "deleted" [ref=e107]
                  - generic [ref=e108]: deleted
                - generic [ref=e109] [cursor=pointer]:
                  - checkbox "needs review" [ref=e110]
                  - generic [ref=e111]: needs review
              - button "More filters" [ref=e113] [cursor=pointer]
          - table [ref=e115]:
            - rowgroup [ref=e116]:
              - row "User Status Organizations Activity Action" [ref=e117]:
                - columnheader "User" [ref=e118]:
                  - link "User" [ref=e119] [cursor=pointer]:
                    - /url: /admin/users?order_by=inserted_at&order_direction=asc&page=1
                - columnheader "Status" [ref=e120]
                - columnheader "Organizations" [ref=e121]
                - columnheader "Activity" [ref=e122]
                - columnheader "Action" [ref=e123]
            - rowgroup [ref=e124]:
              - 'row "org-admin@example.test org-admin@example.test 940a9cda-8561-4a60-b811-1b76fe30b383 ⚠︎ Unconfirmed ⚠︎ No MFA Allowed Org 1 organization Last activity: 2026-10-22 02:43 Registered: 2026-10-22 Open user" [ref=e125]':
                - cell "org-admin@example.test org-admin@example.test 940a9cda-8561-4a60-b811-1b76fe30b383" [ref=e126]:
                  - generic [ref=e127]:
                    - generic [ref=e128]: org-admin@example.test
                    - generic "org-admin@example.test" [ref=e129]
                    - code [ref=e130] [cursor=pointer]: 940a9cda-8561-4a60-b811-1b76fe30b383
                - cell "⚠︎ Unconfirmed ⚠︎ No MFA" [ref=e131]:
                  - generic [ref=e132]:
                    - generic [ref=e133]: ⚠︎ Unconfirmed
                    - generic [ref=e134]: ⚠︎ No MFA
                - cell "Allowed Org 1 organization" [ref=e135]:
                  - generic [ref=e136]:
                    - generic "Allowed Org" [ref=e137]
                    - generic [ref=e138]: 1 organization
                - 'cell "Last activity: 2026-10-22 02:43 Registered: 2026-10-22" [ref=e139]':
                  - generic [ref=e140]:
                    - generic [ref=e141]: "Last activity: 2026-10-22 02:43"
                    - generic [ref=e142]: "Registered: 2026-10-22"
                - cell "Open user" [ref=e143]:
                  - link "Open user" [ref=e144] [cursor=pointer]:
                    - /url: /admin/users/940a9cda-8561-4a60-b811-1b76fe30b383?return_to=%2Fadmin%2Fusers%3Forder_by%3Dinserted_at%26order_direction%3Ddesc
              - 'row "impersonation-target@example.test impersonation-target@example.test 732c3c4c-34a3-4493-9a08-0fd37254a26e ⚠︎ Unconfirmed ⚠︎ No MFA No organizations 0 organizations Last activity: None recorded Registered: 2026-10-22 Open user" [ref=e145]':
                - cell "impersonation-target@example.test impersonation-target@example.test 732c3c4c-34a3-4493-9a08-0fd37254a26e" [ref=e146]:
                  - generic [ref=e147]:
                    - generic [ref=e148]: impersonation-target@example.test
                    - generic "impersonation-target@example.test" [ref=e149]
                    - code [ref=e150] [cursor=pointer]: 732c3c4c-34a3-4493-9a08-0fd37254a26e
                - cell "⚠︎ Unconfirmed ⚠︎ No MFA" [ref=e151]:
                  - generic [ref=e152]:
                    - generic [ref=e153]: ⚠︎ Unconfirmed
                    - generic [ref=e154]: ⚠︎ No MFA
                - cell "No organizations 0 organizations" [ref=e155]:
                  - generic [ref=e156]:
                    - generic "No organizations" [ref=e157]
                    - generic [ref=e158]: 0 organizations
                - 'cell "Last activity: None recorded Registered: 2026-10-22" [ref=e159]':
                  - generic [ref=e160]:
                    - generic [ref=e161]: "Last activity: None recorded"
                    - generic [ref=e162]: "Registered: 2026-10-22"
                - cell "Open user" [ref=e163]:
                  - link "Open user" [ref=e164] [cursor=pointer]:
                    - /url: /admin/users/732c3c4c-34a3-4493-9a08-0fd37254a26e?return_to=%2Fadmin%2Fusers%3Forder_by%3Dinserted_at%26order_direction%3Ddesc
              - 'row "platform-admin@example.test platform-admin@example.test 6ea48559-f95f-4101-8f1e-501dd0594fa3 ⚠︎ Unconfirmed ⚠︎ No MFA No organizations 0 organizations Last activity: 2026-10-22 02:43 Registered: 2026-10-22 Open user" [ref=e165]':
                - cell "platform-admin@example.test platform-admin@example.test 6ea48559-f95f-4101-8f1e-501dd0594fa3" [ref=e166]:
                  - generic [ref=e167]:
                    - generic [ref=e168]: platform-admin@example.test
                    - generic "platform-admin@example.test" [ref=e169]
                    - code [ref=e170] [cursor=pointer]: 6ea48559-f95f-4101-8f1e-501dd0594fa3
                - cell "⚠︎ Unconfirmed ⚠︎ No MFA" [ref=e171]:
                  - generic [ref=e172]:
                    - generic [ref=e173]: ⚠︎ Unconfirmed
                    - generic [ref=e174]: ⚠︎ No MFA
                - cell "No organizations 0 organizations" [ref=e175]:
                  - generic [ref=e176]:
                    - generic "No organizations" [ref=e177]
                    - generic [ref=e178]: 0 organizations
                - 'cell "Last activity: 2026-10-22 02:43 Registered: 2026-10-22" [ref=e179]':
                  - generic [ref=e180]:
                    - generic [ref=e181]: "Last activity: 2026-10-22 02:43"
                    - generic [ref=e182]: "Registered: 2026-10-22"
                - cell "Open user" [ref=e183]:
                  - link "Open user" [ref=e184] [cursor=pointer]:
                    - /url: /admin/users/6ea48559-f95f-4101-8f1e-501dd0594fa3?return_to=%2Fadmin%2Fusers%3Forder_by%3Dinserted_at%26order_direction%3Ddesc
          - text: ⚠︎ ⚠︎ ⚠︎ ⚠︎ ⚠︎ ⚠︎
          - paragraph [ref=e185]: Showing all 3 users
```

# Test source

```ts
  1   | import { test, expect, type Page } from "@playwright/test";
  2   | import AxeBuilder from "@axe-core/playwright";
  3   | import { captureAdminCheckpoint } from "../helpers/adminArtifacts";
  4   | import { adminUsersEmailLocator } from "../helpers/adminUsersIndex";
  5   | import { TEST_PASSWORD } from "../helpers/fixtures";
  6   | 
  7   | // Generated-host admin and adopter-experience parity smoke.
  8   | //
  9   | // Per D-03, D-05, D-17, D-20, D-21, D-24, and D-25 this spec stays narrow and
  10  | // deterministic. It proves installer/template/runtime parity for the shipped
  11  | // admin seams ONLY:
  12  | //
  13  | //   * shell render on desktop and mobile,
  14  | //   * visible scope labels (Global + organization name),
  15  | //   * admin navigation presence (desktop sidebar + mobile bottom nav),
  16  | //   * allowed organization access (200 + scope label + org-scoped admin content),
  17  | //   * denied global admin access (403 + explicit copy),
  18  | //   * not-found out-of-scope organization access (404 + explicit copy).
  19  | //
  20  | // Broader negative-case matrices, sensitive-mutation guards, filter
  21  | // permutations, and example-app workflow depth stay outside this spec — they
  22  | // are owned by `test/sigra/**`, `test/example/test/**`, and the example-app
  23  | // Playwright behavior suite (D-06, D-07, D-15, D-18).
  24  | 
  25  | const platformAdminEmail =
  26  |   process.env.SIGRA_PLATFORM_ADMIN_EMAIL ?? "platform-admin@example.test";
  27  | const orgAdminEmail =
  28  |   process.env.SIGRA_ORG_ADMIN_EMAIL ?? "org-admin@example.test";
  29  | const adminPassword = process.env.SIGRA_ADMIN_PASSWORD ?? TEST_PASSWORD;
  30  | const allowedOrgSlug = process.env.SIGRA_ALLOWED_ORG_SLUG ?? "allowed-org";
  31  | const allowedOrgName = process.env.SIGRA_ALLOWED_ORG_NAME ?? "Allowed Org";
  32  | const otherOrgSlug = process.env.SIGRA_OTHER_ORG_SLUG ?? "other-scope";
  33  | const impersonationTargetEmail =
  34  |   process.env.SIGRA_IMPERSONATION_TARGET_EMAIL ??
  35  |   "impersonation-target@example.test";
  36  | 
  37  | const DESKTOP_VIEWPORT = { width: 1280, height: 900 };
  38  | const MOBILE_VIEWPORT = { width: 390, height: 844 };
  39  | 
  40  | async function waitForLiveViewReady(page: Page) {
> 41  |   await page.waitForSelector("[data-phx-session].phx-connected", {
      |              ^ TimeoutError: page.waitForSelector: Timeout 15000ms exceeded.
  42  |     state: "attached",
  43  |   });
  44  | }
  45  | 
  46  | async function confirmSudo(page: Page, password: string) {
  47  |   await expect(page).toHaveURL(/\/users\/sudo\?/);
  48  |   // Ratified copy per installer template sudo_html.ex and example sudo_html.ex.
  49  |   // The old heading was stale; reconciled to "Re-enter your password" (Phase 208.1-02).
  50  |   await expect(
  51  |     page.getByRole("heading", { name: "Re-enter your password" }),
  52  |   ).toBeVisible();
  53  |   await page.fill('input[name="sudo[password]"]', password);
  54  |   await page.getByRole("button", { name: "Confirm password" }).click();
  55  | }
  56  | 
  57  | /** Admin shell chrome (avoids inner LiveView `<header>` on nested admin pages). */
  58  | function adminShellHeader(page: Page) {
  59  |   return page.locator("header").filter({ hasText: "Admin" }).first();
  60  | }
  61  | 
  62  | async function logIn(
  63  |   page: Parameters<typeof test>[0]["page"],
  64  |   email: string,
  65  |   password: string,
  66  | ) {
  67  |   await page.goto("/users/log_in");
  68  |   await expect(page.getByRole("heading", { name: "Sign in" })).toBeVisible();
  69  |   await page.locator("details.sigra-auth-disclosure > summary").click();
  70  |   const passwordForm = page.locator("#login_form");
  71  |   await passwordForm.getByLabel("Email", { exact: true }).fill(email);
  72  |   await passwordForm.getByLabel("Password", { exact: true }).fill(password);
  73  |   await passwordForm
  74  |     .getByRole("button", { name: "Sign in with password" })
  75  |     .click();
  76  |   await expect(page).not.toHaveURL(/\/users\/log_in(\?|$)/);
  77  | }
  78  | 
  79  | test("generated auth shell communicates hierarchy and survives theme and reflow states", async ({
  80  |   page,
  81  | }, testInfo) => {
  82  |   await page.setViewportSize(DESKTOP_VIEWPORT);
  83  |   await page.goto("/users/log_in");
  84  | 
  85  |   await expect(page.getByRole("heading", { name: "Sign in" })).toBeVisible();
  86  |   await expect(
  87  |     page.getByRole("button", { name: "Email me a sign-in link" }),
  88  |   ).toBeVisible();
  89  | 
  90  |   const alternatives = page.locator("details.sigra-auth-disclosure");
  91  |   await expect(alternatives).not.toHaveAttribute("open", "");
  92  |   const alternativesSummary = alternatives.locator("summary");
  93  |   for (let index = 0; index < 4; index += 1) {
  94  |     await page.keyboard.press("Tab");
  95  |   }
  96  |   await expect(alternativesSummary).toBeFocused();
  97  |   await expect(alternativesSummary).not.toHaveCSS("box-shadow", "none");
  98  |   await page.keyboard.press("Enter");
  99  |   await expect(alternatives).toHaveAttribute("open", "");
  100 |   await expect(
  101 |     page.getByRole("button", { name: "Sign in with password" }),
  102 |   ).toBeVisible();
  103 |   await expect(
  104 |     page.getByRole("heading", { name: "Work sign-in" }),
  105 |   ).toBeVisible();
  106 | 
  107 |   const authAssetBudget = await page.evaluate(() => {
  108 |     const entries = performance
  109 |       .getEntriesByType("resource")
  110 |       .filter((entry) => new URL(entry.name).pathname.endsWith("/sigra_auth.css")) as PerformanceResourceTiming[];
  111 | 
  112 |     return {
  113 |       count: entries.length,
  114 |       decodedBytes: entries.reduce((sum, entry) => sum + entry.decodedBodySize, 0),
  115 |     };
  116 |   });
  117 |   expect(authAssetBudget.count).toBe(1);
  118 |   expect(authAssetBudget.decodedBytes).toBeLessThanOrEqual(35_000);
  119 | 
  120 |   const authRoot = page.locator("main.sigra-auth");
  121 |   await expect(authRoot).toHaveAttribute("data-theme", "system");
  122 |   await page.emulateMedia({ reducedMotion: "reduce" });
  123 | 
  124 |   const themeSnapshot = async (theme: "light" | "dark" | "system") => {
  125 |     await authRoot.evaluate((element, value) => {
  126 |       element.setAttribute("data-theme", value);
  127 |     }, theme);
  128 | 
  129 |     return authRoot.evaluate((element) => {
  130 |       const style = getComputedStyle(element);
  131 |       return {
  132 |         background: style.getPropertyValue("--sigra-auth-bg").trim(),
  133 |         colorScheme: style.colorScheme,
  134 |       };
  135 |     });
  136 |   };
  137 | 
  138 |   const light = await themeSnapshot("light");
  139 |   await captureAdminCheckpoint(page, testInfo, {
  140 |     name: "auth-login-light-desktop",
  141 |     prefix: "auth",
```