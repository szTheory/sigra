# Contributing to Sigra

## Developing

- Elixir/OTP versions are pinned in `.tool-versions`; use `asdf` or your preferred version manager.
- Library tests require PostgreSQL (`PGUSER` / `PGPASSWORD` / `PGHOST`); see `CLAUDE.md` for a Docker one-liner.
- The `test/example` app is the generated-host fixture used by installer drift tests and Playwright smoke runs.

**Releases:** Hex + GitHub releases are automated via **Release Please** on `main` (see [`MAINTAINING.md`](MAINTAINING.md)). Use **conventional commits** (`feat:`, `fix:`, …) so the Release PR gets the right semver bump; routine `mix test` and CI do not require Node.js or external planning audit tooling.

## Reproducing the PR gate locally (mix ci)

Run `mix ci` to reproduce the locally-faithful library gate without leaving your terminal. It chains exactly seven legs in the same order as CI:

1. `format --check-formatted` — committed Elixir sources are formatted.
2. `deps.get --check-locked` — `mix.lock` matches the declared dependencies.
3. `deps.unlock --check-unused` — the lock contains no unused dependency entries.
4. `compile --warnings-as-errors` — library compiles with zero warnings.
5. `test --exclude scaffold` — the ordinary library suite; scaffold-tagged modules are deliberately excluded so no receiver runs twice.
6. `ci.install_golden` — the one explicit `mix test` receiver for all six scaffold modules: upgrade, generator passkeys opt-out, passkeys JS, golden diff, idempotency, and vault promotion. This leg owns those modules exactly once, including golden diff and idempotency.
7. `sigra.dep_off` — dep-off guard: unlocks `:threadline`, re-compiles without it (`--warnings-as-errors`), then runs the tagged `--only threadline_guard` subset.

CI's `library_tests_shard` job is the sole library-suite owner and calls the same command directly with `MIX_ENV=test mix ci`. The byte-stable `Library tests` job remains the protected aggregation of that owner. Local parity is retry-free: retries are not part of `mix ci`.

If `mix ci` is red, your PR will be red. If `mix ci` is green, the locally-faithful portion of the gate is green (CI-only lanes may still fail; see below).

### Prerequisites

**Live Postgres** — every test leg except the planning contract-lock tests requires a live PostgreSQL instance. See `CLAUDE.md` ("Local development prerequisites") for full instructions. Quick path:

```
scripts/db/up.sh        # boots ephemeral Dockerized test PG, writes tmp/db.env
source tmp/db.env       # exports SIGRA_TEST_PG_* into the current shell
```

Without `direnv`, you must `source tmp/db.env` in every new shell before running `mix test` or `mix ci`. If you run a local Postgres on port 5432, the fallback defaults apply automatically.

**phx_new 1.8.8 archive** — the `ci.install_golden` leg generates a Phoenix app via `phx_new` and diffs it against a committed fixture. A different local archive version produces spurious byte-diffs and a red gate. Install the pinned version:

```
mix archive.install --force hex phx_new 1.8.8
```

The fixture is reblessed against 1.8.8 — use this version locally to keep your gate in sync with CI.

### CI-only lanes (intentionally excluded from mix ci)

The following gates run in CI but are excluded from `mix ci` because they either require Ubuntu font metrics or heavy infrastructure that cannot be reproduced faithfully on a local macOS machine:

- **Ubuntu-baselined Playwright visual snapshots** (`admin-checkpoints-*`, `admin-design-*`): pixel baselines are captured on Ubuntu with specific system fonts. Local macOS runs produce sub-pixel font-metric diffs that diverge from the stored PNGs even when the UI is correct. Do **not** re-record baselines locally. Instead, download the `admin-example-report` artifact from the GitHub Actions run and open `playwright-report/index.html` in your browser.
- **Example-app smoke and Playwright lanes** — these boot the generated host and run browser seams against its live dev server. The deterministic browser work remains CI-only. To reproduce its supported package/config surface locally, work from `test/example/priv/playwright`, use `npm test`, and consult `playwright.config.ts`; CI supplies the generated-host server and seam-specific environment.
- **Heavy install and HTTP smokes** — these run the full `phx.new + sigra.install` scaffolding against a live dev server. You can run them manually:
  - `scripts/ci/install-smoke.sh` — scaffolds a new host app and boots it.
  - boot the example app + `scripts/ci/http-smoke.sh` — hits live HTTP endpoints.

### Optional local hygiene (not in the PR gate)

These are useful for code quality but are deliberately **not** part of `mix ci` because they are not required checks in the PR gate. Running them locally may produce reds that CI does not enforce:

- `mix credo --strict`
- `mix dialyzer`

`mix_audit` is also intentionally omitted from the PR gate.

### Known non-regression mix test failures (v1.40)

The following failures appear on a stock v1.40 checkout and are **not regressions** — do not investigate them as new failures:

- **golden_diff_test.exs** — red if your local phx_new archive differs from 1.8.8 (install 1.8.8 to fix).
- **UpgradeIntegrationTest** (3 tests) — require a specific database and environment configuration not present in a default dev setup.

## CI overview

- **Library/scaffold/golden parity** — `MIX_ENV=test mix ci` remains the literal local parity command for the seven-leg library, scaffold, and golden gate. `library_tests_shard` is the direct executor; `library_tests / Library tests` is its byte-stable terminal aggregate and protected check, not a second executor.
- **Example + install matrix** — compiles the example app and runs installer smoke paths.
- **Milestone verification gate** — `scripts/ci/milestone-verification-gate.sh` ensures completed milestone phases keep a verification report on disk.
- **Installer milestone audit** — `scripts/ci/installer-milestone-audit.sh` (paths-filtered on pull requests) encodes critical installer integration checks (INT-01..INT-03).
- **Playwright** — `example_playwright_shard` is the direct five-seam executor for `admin_behavior`, `admin_checkpoints`, `design_gallery`, `non_admin_smoke`, and `demo_showcase`. `example_playwright_smoke / Example Playwright smoke (full lifecycle)` reads those seam results as the terminal aggregate; it does not execute the browser seams itself. Curated admin checkpoint PNGs are collected under `test/example/priv/playwright/artifacts/admin-checkpoints/`.
- **Intentional non-PR signal: admin eval** — `admin_eval_render` is intentionally non-PR and runs on push, schedule, and workflow_dispatch; it is a hard diagnostic signal rather than a PR executor or protected required check.
- **Intentional non-PR signal: design recapture** — `admin_design_recapture` is intentionally non-PR and runs on push, schedule, and workflow_dispatch for its guarded baseline-recapture conditions; it is likewise not a PR executor or protected required check.
- **Admin artifact bundle contract** — after a green Playwright admin run, `scripts/ci/admin-artifact-bundle-contract.sh` asserts the curated PNG bundle meets minimum count and file size.

## Reviewing admin Playwright artifacts

1. Open the GitHub Actions run for **Example Playwright smoke (full lifecycle)** (job id `example_playwright_smoke`) or the generated-host variant **`generated_admin_playwright_smoke`** when reviewing installer parity.
2. Download the **`admin-example-report`** artifact (HTML report plus bundled files).
3. In the extracted tree, open `playwright-report/index.html` and confirm the five checkpoint scenarios appear green for **admin-checkpoints-chromium**, **admin-checkpoints-mobile**, and **admin-checkpoints-dark**.
4. Under `artifacts/admin-checkpoints/`, confirm at least **15** non-trivial PNG files (curated reviewer bundle); the CI step `Admin artifact bundle contract` enforces count and a minimum size per file.
5. For template-only changes, confirm the **Installer milestone audit** job ran on your pull request (it skips when no files under `priv/templates/sigra.install/` or `lib/sigra/install/` changed).

## Playwright reports on GitHub Pages (optional)

This repo can host a browsable mirror of the Playwright HTML report (including **videos** on the checkpoint and generated-host lanes when published via the dedicated workflow).

1. Run **Playwright reports (GitHub Pages)** once on **`main`** (Actions → Run workflow, or wait for schedule / path-filtered push). The job pushes `gh-pages`, then calls the GitHub REST API (`scripts/ci/ensure-github-pages-legacy-branch.sh`) to **create or switch** the repo’s Pages source to **legacy build from branch `gh-pages` at `/`**, so you usually **do not** open **Settings → Pages** manually.
2. Project URL: `https://<owner>.github.io/<repository>/` (for example `https://szTheory.github.io/sigra/`). Private repositories may require a paid GitHub plan for Pages.
3. The site root lists each run under `runs/<YYYYMMDD-<run_id>>/` with a link into `playwright-report/index.html`. Older run folders are pruned (seven-day policy in the assemble script).

**If the API step fails with 403** (some orgs restrict `pages:write` on `GITHUB_TOKEN`), set Pages once in **Settings → Pages** → **Deploy from a branch** → **`gh-pages`** / **`/`**, then re-run the workflow.

**If Pages is already set to “GitHub Actions”** (`build_type: workflow`), the ensure script **does not** change it; use Settings or migrate the workflow to `deploy-pages` yourself.

## Reproducing a failure and reading the Phase 254 comparison

The single result report is [Phase 254 comparison: insufficient data](.planning/execution/255-replay/REPORT.md), with machine-readable values in [REPORT.json](.planning/execution/255-replay/REPORT.json). It links the original run receipts, the later analysis, diagnostic runs, and the immutable replay package. The comparison observed one failed baseline and one successful candidate, zero matched pairs, and null median/p95; CISPEED-01/02 remain open.

### Runtime and database setup

- Use `.tool-versions`: Elixir `1.19.5-otp-28` and Erlang/OTP `28.5`.
- Library tests read `SIGRA_TEST_PG_HOSTNAME`, `SIGRA_TEST_PG_PORT`, `SIGRA_TEST_PG_USERNAME`, `SIGRA_TEST_PG_PASSWORD`, and `SIGRA_TEST_PG_DATABASE` from `config/test.exs`. The example dev app reads the ordinary `PGHOST`, `PGPORT`, `PGUSER`, `PGPASSWORD`, and `PGDATABASE` variables. `scripts/db/up.sh` writes `tmp/db.env` for both conventions; source it in each new shell.
- `mix ci.install_golden` requires the `phx_new 1.8.8` archive. Install that exact version with `mix archive.install --force hex phx_new 1.8.8`.
- The example Playwright suite uses its committed `package-lock.json` and Playwright `1.59.1`. Run `cd test/example/priv/playwright && npm ci && npx playwright install chromium webkit` when preparing the browser tools. Use Ubuntu 24.04 Actions artifacts for screenshot/font comparisons; macOS screenshots are compare-only for behavior review.

Run the same seven-leg local library gate as CI:

```sh
MIX_ENV=test mix ci
```

For an isolated Playwright seam, the local wrapper creates its own database, port, build directory, and server:

```sh
python3 -B scripts/ci/ci-browser-local.py --seam admin_behavior --event pull_request --port 51000 --grep '@smoke search -> filter -> open user -> revoke session keeps scope visible'
```

For the explicit first-failure diagnostics fixture, use a new private output directory and retain it only while inspecting the sanitized result:

```sh
RUN_DIR="$(mktemp -d)"
python3 -B scripts/ci/ci-browser-local.py --seam admin_behavior --event push --port 51001 --diagnostic-case fail --keep-output --output-root "$RUN_DIR"
```

The recorded native failure argv was `node test/example/priv/playwright/node_modules/playwright/cli.js test --config scripts/ci/fixtures/playwright-diagnostics.config.ts --project=chromium --retries=0`; there was no explicit Playwright seed (`null`). The runner-termination case added `--grep "retains a default-context first failure"` and ended with SIGTERM; Phoenix startup/discovery/browser-launch failures had no created Playwright context or seed. The exact per-case argv and unavailable-trace reason are in [BROWSER-DIAGNOSTICS.json](.planning/execution/255-local/BROWSER-DIAGNOSTICS.json). Do not copy raw authentication state or traces into Git; the tracked diagnostics bundle is sanitized.

### Retrieve the saved comparison inputs

The package is on the real remote at `refs/heads/evidence/phase255-replay-6d098e9bee2d28b0d88d`, commit `52d2f3611fa195042d52ab0ef9dba64e4d75a2eb`. Its archive SHA-256 is `6d098e9bee2d28b0d88dda2c517503467448939b4e48af84bf6e2ffd5255fe23`. A clean temporary checkout can retrieve and replay it with:

```sh
REPLAY_DIR="$(mktemp -d)"
git -C "$REPLAY_DIR" init --initial-branch=main
git -C "$REPLAY_DIR" fetch --no-tags https://github.com/szTheory/sigra.git refs/heads/evidence/phase255-replay-6d098e9bee2d28b0d88d
git -C "$REPLAY_DIR" checkout --detach FETCH_HEAD
shasum -a 256 "$REPLAY_DIR/.planning/execution/255-replay/distributed/input-package.tar.gz"
python3 -B "$REPLAY_DIR/scripts/ci/ci-comparison-replay.py" replay --package "$REPLAY_DIR/.planning/execution/255-replay/distributed/input-package.tar.gz" --output "$REPLAY_DIR/replayed-result.json"
```

The hash command must print the value above. Replay checks all package members and blocks network command execution. The tested in-repository distribution verification is `python3 -B scripts/ci/ci-comparison-replay.py verify-distribution --record .planning/execution/255-replay/DISTRIBUTION.json`.

### Download short-lived CI diagnostics

Phase 255 canary artifacts expire after seven days. For example, retrieve the deliberate failure artifact by its exact run and artifact name before **2026-10-31**:

```sh
umask 077
ARTIFACT_DIR="$(mktemp -d)"
gh run download 40123954650 --repo szTheory/sigra --name sigra-ci-7aae47281bb3e91bb38fe2387427f27bd0b44327-40123954650-1-diagnostic-fixture-failure-phase255-failure-1792868930 --dir "$ARTIFACT_DIR"
```

Trace files and browser authentication state can contain session material. Keep downloads in a private temporary directory and never commit raw files. The cancellation run `40124112173` has a partial artifact: `final-output.log` and `final-trace.zip` are absent and were not reconstructed.
