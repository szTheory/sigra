defmodule Sigra.Admin.Live.IndexLive do
  @moduledoc """
  Global admin orientation surface.
  """

  use Phoenix.LiveView

  import Sigra.Admin.Components

  alias Sigra.Admin.Users.Query

  @impl true
  def mount(_params, _session, socket) do
    config = runtime_config!()
    admin_scope = socket.assigns.admin_scope

    {:ok,
     socket
     |> assign(:sigra_config, config)
     |> assign(:summary_stats, Query.summary_stats(config, admin_scope))
     |> assign(:loading, false)
     |> assign(:page_title, "Global overview")}
  end

  @impl true
  def render(assigns) do
    assigns =
      assigns
      |> assign(:summary_growth, summary_group(assigns.summary_stats, :growth))
      |> assign(:summary_activity, summary_group(assigns.summary_stats, :activity))
      |> assign(
        :needs_review,
        Sigra.Admin.needs_review(summary_group(assigns.summary_stats, :posture))
      )

    ~H"""
    <section class="sg-stack sg-stack--6">
      <header class="sg-page-header">
        <p class="sg-page-kicker">Admin overview</p>
        <h1 class="sg-page-title">What do you need to do?</h1>
        <p class="sg-page-copy">
          Start from the job at hand — find a user, investigate an event, or review risky users.
        </p>
      </header>

      <.notice :if={not @loading} tone={if @needs_review > 0, do: :risk, else: :ok}>
        <%= if @needs_review > 0 do %>
          {@needs_review} users need review —
          <.notice_link href="/admin/users?needs_review=true">Review users</.notice_link>
        <% else %>
          No flagged accounts
        <% end %>
      </.notice>

      <div class="sg-grid sg-grid--3">
        <.task_card
          title="Find a user"
          body="Search by email or ID, inspect security state, revoke sessions, and start support actions."
          href="/admin/users"
          action="Find a user"
        />
        <.task_card
          title="Investigate an event"
          body="Filter security events, distinguish actor from effective user, and export CSV evidence."
          href="/admin/audit"
          action="Investigate audit"
        />
        <.task_card
          title="Review risky users"
          body="Jump straight to locked or deletion-scheduled users before they surprise support."
          href="/admin/users?needs_review=true"
          action="Review users"
        />
      </div>

      <% new_this_week = summary_count(@summary_growth, :new_this_week) %>
      <% new_this_month = summary_count(@summary_growth, :new_this_month) %>
      <% active_this_week = summary_count(@summary_activity, :active_this_week) %>
      <% active_this_month = summary_count(@summary_activity, :active_this_month) %>
      <section class="sg-stack sg-stack--3" aria-labelledby="admin-user-snapshot-heading">
        <h2 id="admin-user-snapshot-heading" class="sg-section-heading">User snapshot</h2>
        <dl class="sg-metric-grid" aria-label="User snapshot">
          <.summary_chip
            id="overview-metric-new-users"
            icon="sparkles"
            label="New users"
            value={new_this_week}
            value_suffix="new this week"
            subvalue={month_detail(new_this_week, new_this_month)}
            help="Users registered since Monday UTC and since the first day of this month."
          />
          <.summary_chip
            :if={activity_available?(@summary_activity)}
            id="overview-metric-active-users"
            icon="activity"
            label="Active users"
            value={active_this_week}
            value_suffix="active this week"
            subvalue={month_detail(active_this_week, active_this_month)}
            help="Users with session activity since Monday UTC and since the first day of this month."
          />
        </dl>
      </section>
    </section>
    """
  end

  defp summary_group(stats, key) when is_map(stats), do: Map.get(stats, key, %{})
  defp summary_group(_stats, _key), do: %{}

  defp summary_count(counts, key) when is_map(counts) do
    case Map.get(counts, key, 0) do
      nil -> 0
      value -> value
    end
  end

  defp summary_count(_counts, _key), do: 0

  defp activity_available?(%{available?: true}), do: true
  defp activity_available?(_activity), do: false

  defp month_detail(count, count), do: nil
  defp month_detail(_week_count, month_count), do: "#{month_count} this month"

  defp runtime_config! do
    Sigra.Admin.runtime_config!("Sigra admin overview")
  end
end
